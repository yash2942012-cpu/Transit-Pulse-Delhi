import React from 'react';
import { createRoot } from 'react-dom/client';
import { registerSW } from 'virtual:pwa-register';
import App from './App.jsx';
import './style.css';

const updateSW = registerSW({
  immediate: true,
  onNeedRefresh() {
    if (window.confirm('A TransitPulse update is available. Update now?')) updateSW(true);
  }
});

createRoot(document.getElementById('root')).render(<App />);
