import {cloudEnabled, configurationError, apiFetch, initializeCloud, loginReviewer, logoutReviewer, registerPassenger, signInPassenger, signOutPassenger, sendPasswordReset, updatePassword, onAuthChange, isReviewer} from './lib/cloud.js';
import React, { useState, useEffect } from 'react';
import { 
  Bus, 
  Train, 
  Award, 
  ShoppingBag, 
  ShieldCheck, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Ticket, 
  QrCode, 
  ChevronRight,
  TrendingUp,
  MapPin,
  RefreshCw,
  Sparkles,
  UserCheck,
  Search,
  Check,
  X,
  XCircle,
  Filter,
  BarChart3,
  Users,
  Layers,
  ArrowRight
} from 'lucide-react';

// --- SHARED MOCK DATA ---
const INITIAL_TRIPS = [
  { id: 'dtc-534', mode: 'bus', line: 'Route 534', route: 'Mehrauli ➔ Anand Vihar ISBT', vehicleNo: 'DL 1PC 4821', timing: 'Peak Hours (09:00 AM)', crowd: 'High (Standing Only)', crowdColor: 'text-amber-400 bg-amber-400/10 border-amber-400/30' },
  { id: 'dtc-429', mode: 'bus', line: 'Route 429', route: 'Nehru Place ➔ Kashmere Gate', vehicleNo: 'DL 1PC 9912', timing: 'Off-Peak (02:15 PM)', crowd: 'Low (Seats Available)', crowdColor: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/30' },
  { id: 'metro-yellow', mode: 'metro', line: 'Yellow Line', route: 'Hauz Khas ➔ Rajiv Chowk', vehicleNo: 'Train #Y-402', timing: 'Peak Hours (06:30 PM)', crowd: 'Overcrowded', crowdColor: 'text-rose-400 bg-rose-400/10 border-rose-400/30' },
  { id: 'metro-blue', mode: 'metro', line: 'Blue Line', route: 'Dwarka Sec 21 ➔ Noida City', vehicleNo: 'Train #B-119', timing: 'Off-Peak (11:30 AM)', crowd: 'Moderate', crowdColor: 'text-blue-400 bg-blue-400/10 border-blue-400/30' },
];

const SHOP_ITEMS = [
  { id: 1, title: '1 Free DTC Bus Pass (Single Day)', cost: 35, type: 'bus', code: 'DTC-PASS-8821', desc: 'Valid across all non-AC & AC green/orange DTC buses.' },
  { id: 2, title: '₹35 Delhi Metro Coupon', cost: 145, type: 'metro', code: 'DMRC-VAL-9912', desc: 'Instant wallet top-up voucher for DMRC Smart Pass.' },
  { id: 3, title: '50% Off One Metro Journey', cost: 50, type: 'metro', code: 'DMRC-HALF-3310', desc: 'Valid up to ₹40 discount on any single Metro trip.' },
  { id: 4, title: '1 Free Feeder Bus Pass', cost: 25, type: 'bus', code: 'E-FEED-1002', desc: 'Valid for last-mile feeder buses at major metro stations.' }
];

const INITIAL_QUEUE = [
  {
    id: 'srv-101',
    userName: 'Rahul Sharma',
    userPhone: '+91 9876543210',
    trip: 'Route 534 (DL 1PC 4821)',
    time: '10 mins ago',
    reported: { crowding: 'High / Standing space only', cleanliness: 'Acceptable', acStatus: 'Off / Malfunctioning', issue: 'AC failure in summer peak' },
    telemetryMatch: '98% GTFS Sensor Match (#AC-4821 logs power fault)',
    status: 'pending',
    baseAwarded: 5,
    bonusEligible: 7
  },
  {
    id: 'srv-102',
    userName: 'Priya Verma',
    userPhone: '+91 9123456789',
    trip: 'Yellow Line (Train #Y-402)',
    time: '25 mins ago',
    reported: { crowding: 'Low / Seats available', cleanliness: 'Clean', acStatus: 'Working Fine', issue: 'None' },
    telemetryMatch: '94% Telemetry Match (Gate turnstile count confirms)',
    status: 'pending',
    baseAwarded: 5,
    bonusEligible: 7
  }
];

function CrowdIntelligence({refreshKey=0}) {
 const [data,setData]=useState(null),[error,setError]=useState('');
 const load=()=>apiFetch('/api/crowding').then(r=>r.json()).then(setData).catch(e=>setError(e.message));
 useEffect(()=>{load()},[refreshKey]);
 return <section className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
  <div className="flex justify-between items-center"><h2 className="font-bold text-white flex items-center gap-2"><BarChart3 size={17} className="text-emerald-400"/>Crowding Intelligence</h2><button onClick={load} className="text-xs text-emerald-400">Refresh estimates</button></div>
  <p className="text-xs text-slate-400">Calculated from approved passenger reports within the last 24 hours. Unknown means insufficient evidence, not an empty vehicle.</p>
  {error&&<p className="text-red-400 text-xs">{error}</p>}
  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">{data?.estimates?.map(e=><div key={e.tripId} className="bg-slate-950 border border-slate-800 rounded-xl p-3 space-y-2">
   <div className="flex justify-between text-xs"><strong>{e.name}</strong><span className="text-emerald-300">{e.level}</span></div>
   <div className="h-2 bg-slate-800 rounded-full overflow-hidden">{e.score!==null&&<div className={`h-full ${e.score>=75?'bg-rose-500':e.score>=35?'bg-amber-400':'bg-emerald-500'}`} style={{width:`${e.score}%`}}/>}</div>
   <div className="text-[11px] text-slate-400">{e.score===null?'No verified reports':`${e.score}/100 estimated crowding`} · {e.observations} reports · {e.confidence} confidence</div>
  </div>)}</div>
 </section>
}
function JourneyPlanner() {
 const [network,setNetwork]=useState(null),[origin,setOrigin]=useState('Hauz Khas'),[destination,setDestination]=useState('Rajiv Chowk'),[preference,setPreference]=useState('balanced'),[routes,setRoutes]=useState([]),[error,setError]=useState(''),[searched,setSearched]=useState(false),[loading,setLoading]=useState(false);
 useEffect(()=>{apiFetch('/api/network').then(r=>r.json()).then(setNetwork).catch(e=>setError(e.message))},[]);
 async function search(e){e?.preventDefault();setLoading(true);setError('');try{const r=await apiFetch(`/api/journeys?from=${encodeURIComponent(origin)}&to=${encodeURIComponent(destination)}&preference=${encodeURIComponent(preference)}`);const d=await r.json();if(!r.ok)throw Error(d.error);setRoutes(d.routes);setSearched(true)}catch(e){setError(e.message)}finally{setLoading(false)}}
 return <section className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
  <div><h2 className="text-lg font-extrabold text-white flex items-center gap-2"><MapPin size={19} className="text-emerald-400"/>Crowding-Aware Journey Planner</h2><p className="text-xs text-amber-300 mt-1">DEMO NETWORK — illustrative stops, links and travel times; not official Delhi routes or schedules.</p></div>
  <form onSubmit={search} className="grid grid-cols-1 md:grid-cols-4 gap-3">
   <label className="text-xs text-slate-400">From<select value={origin} onChange={e=>setOrigin(e.target.value)} className="mt-1 block w-full p-2 rounded-lg bg-slate-950 border border-slate-700 text-white">{network?.stops?.map(s=><option key={s}>{s}</option>)}</select></label>
   <label className="text-xs text-slate-400">To<select value={destination} onChange={e=>setDestination(e.target.value)} className="mt-1 block w-full p-2 rounded-lg bg-slate-950 border border-slate-700 text-white">{network?.stops?.map(s=><option key={s}>{s}</option>)}</select></label>
   <label className="text-xs text-slate-400">Priority<select value={preference} onChange={e=>setPreference(e.target.value)} className="mt-1 block w-full p-2 rounded-lg bg-slate-950 border border-slate-700 text-white"><option value="balanced">Balanced</option><option value="fastest">Fastest</option><option value="less-crowded">Less crowded</option></select></label>
   <button disabled={!network||loading} className="self-end bg-emerald-500 text-slate-950 font-bold rounded-lg p-2 disabled:opacity-50">{loading?'Calculating…':'Find journeys'}</button>
  </form>
  {error&&<p className="text-xs text-rose-400">{error}</p>}
  {searched&&routes.length===0&&<p className="text-sm text-slate-400">No route found in the illustrative network. Try different stops.</p>}
  <div className="space-y-3">{routes.map((r,i)=><div key={i} className={`rounded-xl border p-4 ${i===0?'border-emerald-500/50 bg-emerald-950/20':'border-slate-800 bg-slate-950'}`}>
   <div className="flex flex-wrap items-center justify-between gap-2"><strong className="text-sm">{i===0?'Recommended':'Alternative '+i}</strong><span className="text-xs text-emerald-300">{r.estimatedMinutes} min · {r.transfers} transfers · {r.crowdLevel} crowding</span></div>
   <p className="text-[11px] text-slate-400 mt-1">Crowding confidence: {r.confidence}. {r.crowdScore===null?'No approved observations available.':`Estimated crowding index: ${r.crowdScore}/100.`}</p>
   <div className="mt-3 space-y-2">{r.legs.map((l,j)=><div key={j} className="text-xs flex flex-wrap gap-2 items-center"><span className="rounded bg-slate-800 px-2 py-1">{l.line}</span><span>{l.from} → {l.to}</span><span className="text-slate-500">{l.minutes} min</span></div>)}</div>
  </div>)}</div>
 </section>
}
function ReviewerAnalytics({pin,refreshKey}){
 const [data,setData]=useState(null),[error,setError]=useState('');
 async function load(){if(!pin&&!cloudEnabled){setError('Enter the reviewer demo PIN first.');return}try{const r=await apiFetch('/api/reviewer/analytics',{headers:{'x-reviewer-pin':pin}});const d=await r.json();if(!r.ok)throw Error(d.error);setData(d);setError('')}catch(e){setError(e.message)}}
 useEffect(()=>{if((pin||cloudEnabled)&&refreshKey>0)load()},[refreshKey]);
 return <section className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3"><div className="flex justify-between"><h2 className="font-bold text-white">Authority Analytics — Demo</h2><button onClick={load} className="text-emerald-400 text-xs">Load analytics</button></div>
 <p className="text-xs text-slate-400">Aggregate statistics from demonstration reports, not official authority data.</p>{error&&<p className="text-xs text-rose-400">{error}</p>}
 {data&&<><div className="grid grid-cols-3 gap-2">{Object.entries(data.counts).map(([k,v])=><div key={k} className="rounded-lg bg-slate-950 p-3"><div className="text-xs text-slate-400 capitalize">{k}</div><div className="text-xl font-bold">{v}</div></div>)}</div><h3 className="text-xs font-bold">Reported crowding by line</h3><div className="grid grid-cols-2 gap-2">{data.estimates.map(e=><div key={e.tripId} className="bg-slate-950 rounded-lg p-3 text-xs">{e.name}: <span className="text-emerald-400">{e.level}</span><div className="text-slate-500">{e.observations} approved recent reports</div></div>)}</div><h3 className="text-xs font-bold">Verified issue reports</h3>{data.issues.length?data.issues.map(x=><div key={x.name} className="text-xs text-slate-300">{x.name}: {x.count}</div>):<p className="text-xs text-slate-500">No approved issue reports yet.</p>}</>}
 </section>
}

function PassengerAuth({onSignedIn,recoveryMode=false,onRecoveryComplete}){
 const [mode,setMode]=useState(recoveryMode?'new-password':'login');
 const [confirmPassword,setConfirmPassword]=useState('');
 const [email,setEmail]=useState('');
 const [password,setPassword]=useState('');
 const [message,setMessage]=useState('');
 const [error,setError]=useState('');
 const [busy,setBusy]=useState(false);
 async function submit(e){
  e.preventDefault();setError('');setMessage('');
  if(mode==='new-password' && password!==confirmPassword){setError('Passwords do not match.');return;}
  setBusy(true);
  try{
   if(mode==='register'){
    const result=await registerPassenger(email,password);
    if(result.session)onSignedIn(result.session);
    else setMessage('Check your inbox for the confirmation link, then sign in.');
   }else if(mode==='reset'){
    await sendPasswordReset(email);
    setMessage('If the address is registered, a password reset email has been sent.');
   }else if(mode==='new-password'){
    await updatePassword(password);
    setMessage('Password updated successfully.');
    setPassword('');setConfirmPassword('');
    onRecoveryComplete?.();
   }else{
    const session=await signInPassenger(email,password);
    onSignedIn(session);
   }
  }catch(err){setError(err.message)}finally{setBusy(false)}
 }
 useEffect(()=>{if(recoveryMode)setMode('new-password')},[recoveryMode]);
 return <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-5">
  <div className="w-full max-w-md rounded-2xl border border-slate-700 bg-slate-900 p-7 shadow-2xl space-y-5">
   <div className="text-2xl font-extrabold text-emerald-400">TransitPulse Delhi</div>
   <p className="text-sm text-slate-400">{mode==='new-password'?'Choose a new password for your account.':'Sign in to save surveys, points and demonstration vouchers across visits.'}</p>
   {mode!=='new-password'&&<div className="flex flex-wrap gap-2 text-xs">{[['login','Sign in'],['register','Create account'],['reset','Forgot password']].map(([key,label])=><button key={key} type="button" onClick={()=>{setMode(key);setError('');setMessage('')}} className={'rounded-lg px-3 py-2 '+(mode===key?'bg-emerald-500 text-slate-950 font-bold':'bg-slate-800 text-slate-200')}>{label}</button>)}</div>}
   <form onSubmit={submit} className="space-y-3">
    {mode!=='new-password'&&<label className="block text-sm">Email<input required type="email" autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 p-3"/></label>}
    {(mode==='login'||mode==='register'||mode==='new-password')&&<label className="block text-sm">{mode==='new-password'?'New password':'Password'}<input required minLength={8} type="password" autoComplete={mode==='login'?'current-password':'new-password'} value={password} onChange={e=>setPassword(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 p-3"/></label>}
    {mode==='new-password'&&<label className="block text-sm">Confirm new password<input required minLength={8} type="password" autoComplete="new-password" value={confirmPassword} onChange={e=>setConfirmPassword(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 p-3"/></label>}
    {error&&<p role="alert" className="text-sm text-rose-300">{error}</p>}
    {message&&<p role="status" className="text-sm text-emerald-300">{message}</p>}
    <button disabled={busy} className="w-full rounded-lg bg-emerald-500 p-3 font-bold text-slate-950 disabled:opacity-50">{busy?'Please wait…':mode==='register'?'Create account':mode==='reset'?'Send reset email':mode==='new-password'?'Save new password':'Sign in'}</button>
   </form>
   <p className="text-xs text-slate-500">Demo tickets and vouchers are not valid for travel. Your email identifies your account, not your real-world identity.</p>
  </div>
 </div>;
}

export default function App() {
  // Application Mode Switcher: 'passenger' or 'reviewer'
  const APP_ROLE = 'passenger';
  const [appMode] = useState(APP_ROLE);
  const setAppMode = () => {};

  // Passenger App State
  const [passengerTab, setPassengerTab] = useState('survey');
  const [intelligenceRefresh,setIntelligenceRefresh]=useState(0);
  const [reviewRefresh,setReviewRefresh]=useState(0); // 'survey' | 'shop'
  const [userPoints, setUserPoints] = useState(0);
  const [ticketCode,setTicketCode]=useState('');
  const [apiError,setApiError]=useState('');
  const [busy,setBusy]=useState(false);
  const [reviewerPin,setReviewerPin]=useState('');
  const [reviewerEmail,setReviewerEmail]=useState('');
  const [reviewerPassword,setReviewerPassword]=useState('');
  const [reviewerLoggedIn,setReviewerLoggedIn]=useState(false);
  const [cloudUserReady,setCloudUserReady]=useState(!cloudEnabled&&!configurationError);
  const [authChecking,setAuthChecking]=useState(cloudEnabled);
  const [signedInEmail,setSignedInEmail]=useState('');
  const [recoveryActive,setRecoveryActive]=useState(false);
  useEffect(()=>{
   if(!cloudEnabled)return;
   let alive=true;
   initializeCloud().then(async session=>{
    if(!alive)return;
    setCloudUserReady(Boolean(session));setSignedInEmail(session?.user?.email||'');
    if(session && APP_ROLE === 'reviewer'){try{setReviewerLoggedIn(await isReviewer())}catch{setReviewerLoggedIn(false)}}
    setAuthChecking(false);
   }).catch(e=>{if(alive){setApiError(e.message);setAuthChecking(false)}});
   const unsubscribe=onAuthChange((session,event)=>{
    if(event==='PASSWORD_RECOVERY')setRecoveryActive(true);
    if(!alive)return;
    setCloudUserReady(Boolean(session));setSignedInEmail(session?.user?.email||'');
    if(!session){setReviewerLoggedIn(false);setUserPoints(0);setMyVouchers([]);setServerReady(false)}
   });
   return ()=>{alive=false;unsubscribe()};
  },[]);
  function finishRecovery(){
   setRecoveryActive(false);
   window.history.replaceState(null,'',window.location.pathname);
  }
  async function signOutAccount(){try{await signOutPassenger();setAppMode('passenger');setReviewerLoggedIn(false)}catch(e){setApiError(e.message)}}
  async function signInReviewer(e){e.preventDefault();setReviewerError('');try{await loginReviewer(reviewerEmail,reviewerPassword);setReviewerLoggedIn(true);await refreshReviewer()}catch(e){setReviewerError(e.message)}}
  async function signOutReviewer(){await logoutReviewer();setReviewerLoggedIn(false);setVerificationQueue([]);setReviewerError('');setAppMode('passenger')}
  const [reviewerError,setReviewerError]=useState('');
  const [serverReady,setServerReady]=useState(false);
  useEffect(()=>{if(APP_ROLE !== 'passenger')return;if(configurationError){setApiError(configurationError);return;}if(!cloudUserReady)return;apiFetch('/api/state').then(r=>{if(!r.ok)return r.json().then(d=>{throw Error(d.error||'API offline')});return r.json()}).then(d=>{setUserPoints(d.points);setMyVouchers(d.vouchers);setServerReady(true)}).catch(e=>setApiError(cloudEnabled?e.message:'Local API is offline. Start npm run server only when VITE_USE_LOCAL_API=true.'))},[cloudUserReady]);
  async function refreshReviewer(){try{const r=await apiFetch('/api/reviewer/reports',{headers:{'x-reviewer-pin':reviewerPin}});const d=await r.json();if(!r.ok)throw Error(d.error);setVerificationQueue(d.reports);setReviewerError('');setReviewRefresh(x=>x+1)}catch(e){setReviewerError(e.message)}}
  const [selectedTrip, setSelectedTrip] = useState(INITIAL_TRIPS[0]);
  const [surveySubmitted, setSurveySubmitted] = useState(false);
  const [myVouchers, setMyVouchers] = useState([]);
  const [activeVoucherModal, setActiveVoucherModal] = useState(null);

  // Survey Form Inputs
  const [crowding, setCrowding] = useState('Moderate (Standing)');
  const [cleanliness, setCleanliness] = useState('Clean');
  const [acStatus, setAcStatus] = useState('Working Fine');
  const [issueType, setIssueType] = useState('none');
  const [notes, setNotes] = useState('');

  // Reviewer App State
  const [verificationQueue, setVerificationQueue] = useState([]);
  const [inspectorQuery, setInspectorQuery] = useState('');
  const [inspectedUser, setInspectedUser] = useState(null);

  // Server-backed demonstration workflow (NOT connected to real transit systems).
  const handleSurveySubmit = async (e) => {
    e.preventDefault();setApiError('');setBusy(true);
    try {
      const r=await apiFetch('/api/surveys',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ticketCode,tripId:selectedTrip.id,trip:`${selectedTrip.line} (${selectedTrip.vehicleNo})`,crowding,cleanliness,acStatus,issueType})});
      const d=await r.json();if(!r.ok)throw Error(d.error);
      setUserPoints(d.points);setSurveySubmitted(true);setTicketCode('');setIntelligenceRefresh(x=>x+1);
    }catch(e){setApiError(e.message)}finally{setBusy(false)}
  };
  const handleReviewAction = async (id,action) => {
    setReviewerError('');
    try{const r=await apiFetch(`/api/reviewer/reports/${id}/decision`,{method:'POST',headers:{'Content-Type':'application/json','x-reviewer-pin':reviewerPin},body:JSON.stringify({action})});const d=await r.json();if(!r.ok)throw Error(d.error);if(!cloudEnabled)setUserPoints(d.points);setIntelligenceRefresh(x=>x+1);await refreshReviewer()}
    catch(e){setReviewerError(e.message)}
  };
  const handleRedeem = async (item) => {
    setApiError('');try{const r=await apiFetch('/api/redeem',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({itemId:item.id})});const d=await r.json();if(!r.ok)throw Error(d.error);setUserPoints(d.points);setMyVouchers(v=>[d.voucher,...v]);setActiveVoucherModal(d.voucher)}catch(e){setApiError(e.message)}
  };

  // Inspector Search
  const handleInspectorSearch = (e) => {
    e.preventDefault();
    if(cloudEnabled){setReviewerError('Wallet inspector is disabled in cloud mode to protect passenger privacy.');return;}
    setInspectedUser({
      name: 'Demo Passenger',
      phone: inspectorQuery || '+91 9876543210',
      totalEarned: 112,
      currentBalance: userPoints,
      surveysCount: 8,
      vouchers: myVouchers
    });
  };

  if(cloudEnabled && authChecking)return <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center">Restoring your session…</div>;
  if(cloudEnabled && recoveryActive)return <PassengerAuth recoveryMode onRecoveryComplete={finishRecovery} onSignedIn={()=>{}}/>;
  if(cloudEnabled && !cloudUserReady && APP_ROLE !== 'reviewer')return <PassengerAuth onSignedIn={()=>{setCloudUserReady(true);setApiError('')}}/>;
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      
      {apiError && <div className="bg-rose-950 text-rose-200 text-xs p-3 text-center">{apiError}</div>}
      {cloudEnabled && <div className="bg-slate-900 border-b border-slate-800 px-5 py-2 text-xs flex justify-end items-center gap-3"><span className="text-slate-300">{signedInEmail}</span><button onClick={signOutAccount} className="rounded bg-slate-700 px-3 py-1.5 hover:bg-slate-600">Sign out</button></div>}
      {/* ========================================================================= */}
      {/* APPLICATION 1: PASSENGER APP                                              */}
      {/* ========================================================================= */}
      {appMode === 'passenger' && (
        <div className="flex-1 max-w-5xl w-full mx-auto p-4 md:p-6 space-y-6">
          
          {/* Passenger Sub-Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-slate-900 border border-slate-800 p-4 rounded-2xl gap-3">
            <div>
              <h1 className="text-lg font-extrabold text-white">Commuter Survey & Rewards</h1>
              <p className="text-xs text-slate-400">Track Delhi transit crowd levels, take surveys & earn ticket vouchers</p>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-xl">
                <Award className="text-amber-400" size={18} />
                <div className="text-left">
                  <div className="text-[9px] uppercase text-slate-400 font-bold">Wallet Balance</div>
                  <div className="text-sm font-black text-amber-400 leading-none">{userPoints} PTS</div>
                </div>
              </div>

              <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
                <button
                  onClick={() => setPassengerTab('survey')}
                  className={`px-3 py-1.5 rounded-lg font-medium ${passengerTab === 'survey' ? 'bg-slate-800 text-white font-bold' : 'text-slate-400'}`}
                >
                  Surveys
                </button>
                <button
                  onClick={() => setPassengerTab('shop')}
                  className={`px-3 py-1.5 rounded-lg font-medium ${passengerTab === 'shop' ? 'bg-slate-800 text-white font-bold' : 'text-slate-400'}`}
                >
                  Shop ({SHOP_ITEMS.length})
                </button>
                <button onClick={() => setPassengerTab('planner')} className={`px-3 py-1.5 rounded-lg font-medium ${passengerTab === 'planner' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400'}`}>Journey Planner</button>
              </div>
            </div>
          </div>

          {passengerTab === 'planner' ? (<div className="space-y-5"><JourneyPlanner/><CrowdIntelligence refreshKey={intelligenceRefresh}/></div>) : passengerTab === 'survey' ? (
            <div className="space-y-6">
              
              {/* Live Crowd & Route Tracker */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 md:p-5">
                <div className="flex items-center justify-between mb-3">
                  <h2 className="text-sm font-bold text-white flex items-center gap-2">
                    <MapPin size={16} className="text-emerald-400" /> Live Bus & Metro Crowd Tracker
                  </h2>
                  <span className="text-[11px] text-emerald-400 flex items-center gap-1">
                    <RefreshCw size={11} /> Sample route data
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {INITIAL_TRIPS.map((trip) => (
                    <div
                      key={trip.id}
                      onClick={() => {
                        setSelectedTrip(trip);
                        setSurveySubmitted(false);
                      }}
                      className={`cursor-pointer p-3.5 rounded-xl border transition flex items-center justify-between ${
                        selectedTrip.id === trip.id
                          ? 'bg-emerald-950/30 border-emerald-500 shadow-md ring-1 ring-emerald-500'
                          : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`p-2.5 rounded-xl ${trip.mode === 'bus' ? 'bg-amber-500/10 text-amber-400' : 'bg-blue-500/10 text-blue-400'}`}>
                          {trip.mode === 'bus' ? <Bus size={18} /> : <Train size={18} />}
                        </div>
                        <div>
                          <div className="font-bold text-xs text-white">{trip.line}</div>
                          <div className="text-[11px] text-slate-400">{trip.route}</div>
                          <div className="text-[10px] text-slate-500 font-mono mt-0.5">{trip.timing}</div>
                        </div>
                      </div>

                      <span className={`text-[10px] font-bold px-2 py-1 rounded-full border ${trip.crowdColor}`}>
                        {trip.crowd}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Micro Survey Box */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 md:p-5">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div>
                    <h2 className="text-sm font-bold text-white flex items-center gap-2">
                      Trip Micro-Survey ({selectedTrip.line})
                    </h2>
                    <p className="text-xs text-slate-400">Share ground reality to help Delhi Transport Stack solve issues</p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-black text-amber-400 block">+5 Base PTS</span>
                    <span className="text-[10px] text-slate-500">+7 Bonus if Verified</span>
                  </div>
                </div>

                {surveySubmitted ? (
                  <div className="py-8 text-center space-y-3">
                    <CheckCircle2 size={40} className="text-emerald-400 mx-auto" />
                    <h3 className="text-base font-bold text-white">Survey Submitted Successfully!</h3>
                    <p className="text-xs text-emerald-400 font-medium">+5 demo points saved on the server.</p>
                    <p className="text-[11px] text-slate-400 max-w-sm mx-auto">
                      A demo reviewer can approve the report to award +7 additional demo points. No automated telemetry validation is claimed.
                    </p>
                    <button
                      onClick={() => setSurveySubmitted(false)}
                      className="bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white px-4 py-2 rounded-xl transition"
                    >
                      Submit Another Survey
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSurveySubmit} className="mt-4 space-y-4"><div><label className="block text-xs font-semibold text-slate-300 mb-1.5">Demo ticket for selected route (required)</label><input value={ticketCode} onChange={e=>setTicketCode(e.target.value)} placeholder="e.g. DEMO-534-A" required className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2.5 text-xs text-white"/><p className="text-[10px] text-slate-400 mt-1">Route 534: DEMO-534-A • 429: DEMO-429-B • Yellow: DEMO-YELLOW-C • Blue: DEMO-BLUE-D. Each ticket works once.</p></div>
                    
                    {/* Crowding Options */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">1. Observed Crowding Level</label>
                      <div className="grid grid-cols-3 gap-2">
                        {['Low (Seats Free)', 'Moderate (Standing)', 'Overcrowded'].map((c) => (
                          <button
                            key={c}
                            type="button"
                            onClick={() => setCrowding(c)}
                            className={`py-2 text-xs rounded-lg border font-medium transition ${
                              crowding === c ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300' : 'bg-slate-950 border-slate-800 text-slate-400'
                            }`}
                          >
                            {c}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Cleanliness */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">2. Vehicle Cleanliness</label>
                      <div className="grid grid-cols-3 gap-2">
                        {['Clean', 'Acceptable', 'Dirty'].map((cl) => (
                          <button
                            key={cl}
                            type="button"
                            onClick={() => setCleanliness(cl)}
                            className={`py-2 text-xs rounded-lg border font-medium transition ${
                              cleanliness === cl ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300' : 'bg-slate-950 border-slate-800 text-slate-400'
                            }`}
                          >
                            {cl}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* AC Status */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">3. Air Conditioning Condition</label>
                      <div className="grid grid-cols-3 gap-2">
                        {['Working Fine', 'AC Off / Broken', 'No Ventilation'].map((a) => (
                          <button
                            key={a}
                            type="button"
                            onClick={() => setAcStatus(a)}
                            className={`py-2 text-xs rounded-lg border font-medium transition ${
                              acStatus === a ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300' : 'bg-slate-950 border-slate-800 text-slate-400'
                            }`}
                          >
                            {a}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Operational Issue */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">4. Unresolved Operational Issue (if any)</label>
                      <select
                        value={issueType}
                        onChange={(e) => setIssueType(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                      >
                        <option value="none">No issues - Smooth ride</option>
                        <option value="Unannounced Delay">Unannounced Schedule Delay</option>
                        <option value="Broken Ticket Machine">Broken Ticket ETM Machine</option>
                        <option value="Skipped Stop">Bus Skipped Bus Stop</option>
                      </select>
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black py-3 rounded-xl text-xs transition shadow-lg shadow-emerald-500/20"
                    >
                      {busy ? 'Submitting...' : 'Submit & Collect 5 Demo Points'}
                    </button>
                  </form>
                )}
              </div>

            </div>
          ) : (
            /* PASSENGER SHOP TAB */
            <div className="space-y-6">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
                <h2 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
                  <ShoppingBag size={16} className="text-amber-400" /> Redeem Points Shop
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {SHOP_ITEMS.map((item) => {
                    const canAfford = userPoints >= item.cost;
                    return (
                      <div key={item.id} className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
                        <div>
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-[10px] font-bold uppercase text-slate-400">{item.type}</span>
                            <span className="text-xs font-black text-amber-400">{item.cost} PTS</span>
                          </div>
                          <h3 className="text-xs font-bold text-white mb-1">{item.title}</h3>
                          <p className="text-[11px] text-slate-400 mb-4">{item.desc}</p>
                        </div>

                        <button
                          onClick={() => handleRedeem(item)}
                          disabled={!canAfford}
                          className={`w-full py-2 rounded-lg text-xs font-bold transition ${
                            canAfford
                              ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                              : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                          }`}
                        >
                          {canAfford ? 'Redeem Ticket' : `Need ${item.cost - userPoints} More PTS`}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* My Wallet Vouchers */}
              {myVouchers.length > 0 && (
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
                  <h3 className="text-xs font-bold text-white mb-3">My Redeemed Ticket Vouchers</h3>
                  <div className="space-y-2">
                    {myVouchers.map((v, i) => (
                      <div key={i} className="bg-slate-950 border border-emerald-500/30 p-3 rounded-xl flex items-center justify-between text-xs">
                        <div>
                          <div className="font-bold text-white">{v.title}</div>
                          <div className="text-[10px] text-emerald-400 font-mono">{v.code}</div>
                        </div>
                        <button
                          onClick={() => setActiveVoucherModal(v)}
                          className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-3 py-1 rounded-lg font-bold flex items-center gap-1"
                        >
                          <QrCode size={12} /> Show QR
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

        </div>
      )}

      {/* ========================================================================= */}
      {/* APPLICATION 2: REVIEWER / TRANSPORT STACK EMPLOYEE PORTAL               */}
      {/* ========================================================================= */}
      {appMode === 'reviewer' && (
        <div className="flex-1 max-w-5xl w-full mx-auto p-4 md:p-6 space-y-6">
          
          {/* Reviewer Header */}
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase mb-1">
                <ShieldCheck size={16} /> Internal Verification Console
              </div>
              <h1 className="text-lg font-bold text-white">Transport Stack Auditor Portal</h1>
              <p className="text-xs text-slate-400">Review demo surveys. No GTFS telemetry verification is implemented.</p>
            </div>

            <div className="bg-slate-950 border border-slate-800 px-3 py-2 rounded-xl text-center">
              <span className="text-[10px] text-slate-500 uppercase block">Pending Queue</span>
              <span className="text-sm font-black text-amber-400">
                {verificationQueue.filter(q => q.status === 'pending').length} Surveys
              </span>
            </div>
          </div>

          {cloudEnabled ? <div className="space-y-2">{!reviewerLoggedIn ? <form onSubmit={signInReviewer} className="flex flex-wrap gap-2"><input type="email" required placeholder="Reviewer email" value={reviewerEmail} onChange={e=>setReviewerEmail(e.target.value)} className="bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs"/><input type="password" required placeholder="Password" value={reviewerPassword} onChange={e=>setReviewerPassword(e.target.value)} className="bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs"/><button className="bg-emerald-500 text-slate-950 px-3 py-2 rounded-lg text-xs font-bold">Reviewer sign in</button></form> : <div className="flex gap-2"><button onClick={refreshReviewer} className="bg-emerald-500 text-slate-950 px-3 py-2 rounded-lg text-xs font-bold">Refresh queue</button><button onClick={signOutReviewer} className="bg-slate-800 px-3 py-2 rounded-lg text-xs">Sign out reviewer</button></div>}</div> : <div className="flex gap-2 items-center"><input type="password" placeholder="Reviewer demo PIN" value={reviewerPin} onChange={e=>setReviewerPin(e.target.value)} className="bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs"/><button onClick={refreshReviewer} className="bg-emerald-500 text-slate-950 px-3 py-2 rounded-lg text-xs font-bold">Load queue</button></div>}{reviewerError && <p className="text-red-400 text-xs">{reviewerError}</p>}
          {(!cloudEnabled||reviewerLoggedIn)&&<ReviewerAnalytics pin={reviewerPin} refreshKey={reviewRefresh}/>}
          {/* Section 1: Survey Data Verification Queue */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
            <h2 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
              <Filter size={16} className="text-emerald-400" /> Incoming Survey Verification Queue
            </h2>

            <div className="space-y-3">
              {verificationQueue.map((item) => (
                <div key={item.id} className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-2 gap-2">
                    <div>
                      <span className="text-xs font-bold text-white">{item.userName}</span>
                      <span className="text-[11px] text-slate-400 block">{item.trip} • {item.time}</span>
                    </div>

                    <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${
                      item.status === 'pending' ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' :
                      item.status === 'approved' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' :
                      'bg-rose-500/10 text-rose-400 border-rose-500/30'
                    }`}>
                      {item.status.toUpperCase()}
                    </span>
                  </div>

                  {/* Reported Info */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] bg-slate-900 p-2.5 rounded-lg">
                    <div>
                      <span className="text-slate-500 block text-[9px]">Crowd</span>
                      <span className="text-slate-200 font-semibold">{item.reported.crowding}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[9px]">AC Status</span>
                      <span className="text-slate-200 font-semibold">{item.reported.acStatus}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[9px]">Cleanliness</span>
                      <span className="text-slate-200 font-semibold">{item.reported.cleanliness}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[9px]">Issue Flag</span>
                      <span className="text-amber-400 font-semibold">{item.reported.issue}</span>
                    </div>
                  </div>

                  {/* GTFS Telemetry AI Crosscheck */}
                  <div className="text-xs bg-emerald-950/20 border border-emerald-500/20 p-2 rounded-lg text-emerald-300 font-mono">
                    🤖 {item.telemetryMatch}
                  </div>

                  {/* Action Buttons */}
                  {item.status === 'pending' && (
                    <div className="flex gap-2 pt-1">
                      <button
                        onClick={() => handleReviewAction(item.id, 'approved')}
                        className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-1.5 rounded-lg text-xs transition flex items-center justify-center gap-1"
                      >
                        <UserCheck size={14} /> Approve & Release +7 Bonus PTS
                      </button>
                      <button
                        onClick={() => handleReviewAction(item.id, 'rejected')}
                        className="bg-slate-800 hover:bg-rose-900/50 text-rose-400 border border-slate-700 font-bold px-3 py-1.5 rounded-lg text-xs transition"
                      >
                        Reject
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Section 2: User Profile & Wallet Inspector */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
            <h2 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
              <Search size={16} className="text-emerald-400" /> User Wallet & Coupon Addition Inspector
            </h2>

            <form onSubmit={handleInspectorSearch} className="flex gap-2 mb-4">
              <input
                type="text"
                placeholder="Enter User Phone (+91 9876543210)"
                value={inspectorQuery}
                onChange={(e) => setInspectorQuery(e.target.value)}
                className="flex-1 bg-slate-950 border border-slate-800 text-xs text-slate-200 p-2.5 rounded-xl outline-none focus:border-emerald-500 font-mono"
              />
              <button
                type="submit"
                className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold px-4 py-2.5 rounded-xl transition"
              >
                Inspect User Profile
              </button>
            </form>

            {inspectedUser && (
              <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-3 text-xs">
                <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                  <div>
                    <span className="font-bold text-white text-sm">{inspectedUser.name}</span>
                    <span className="text-slate-400 text-[11px] block">{inspectedUser.phone}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-amber-400 font-black text-sm">{inspectedUser.currentBalance} PTS</span>
                    <span className="text-[10px] text-slate-500 block">Active Wallet Balance</span>
                  </div>
                </div>

                <div>
                  <span className="text-slate-400 text-[10px] uppercase font-bold block mb-1">Redeemed Coupons Wallet Status</span>
                  {inspectedUser.vouchers.length === 0 ? (
                    <div className="text-slate-500">No coupons redeemed yet.</div>
                  ) : (
                    <div className="space-y-1.5">
                      {inspectedUser.vouchers.map((v, idx) => (
                        <div key={idx} className="bg-slate-900 p-2.5 rounded-lg border border-slate-800 flex justify-between items-center">
                          <div>
                            <span className="font-bold text-slate-200">{v.title}</span>
                            <span className="text-[10px] text-slate-500 font-mono block">{v.code}</span>
                          </div>
                          <span className="text-emerald-400 text-[10px] font-bold bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded">
                            {v.status || 'Successfully Added'}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

        </div>
      )}

      {/* QR CODE VOUCHER MODAL */}
      {activeVoucherModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xs w-full p-5 text-center space-y-3 relative">
            <button
              onClick={() => setActiveVoucherModal(null)}
              className="absolute top-3 right-3 text-slate-400 hover:text-white"
            >
              <X size={16} />
            </button>

            <h3 className="text-sm font-bold text-white">{activeVoucherModal.title}</h3>
            
            <div className="bg-white p-3 rounded-xl inline-block border-2 border-emerald-500">
              <QrCode size={120} className="text-slate-950" />
            </div>

            <div className="bg-slate-950 p-2 rounded-lg font-mono text-xs text-amber-400 font-bold">
              {activeVoucherModal.code}
            </div>

            <p className="text-[10px] text-amber-400">DEMO ONLY — NOT VALID FOR TRAVEL. This icon is not a scannable ticket.</p>
          </div>
        </div>
      )}

    </div>
  );
}