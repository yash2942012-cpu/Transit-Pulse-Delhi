package in.transitpulse.delhi;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
